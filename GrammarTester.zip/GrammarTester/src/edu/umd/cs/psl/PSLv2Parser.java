// Generated from /Users/bach/NetBeansProjects/GrammarTester/src/edu/umd/cs/psl/PSLv2.g4 by ANTLR 4.0
package edu.umd.cs.psl;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class PSLv2Parser extends Parser {
	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		IS_A=1, CONSTANT=2, CARET=3, NOT=4, PLUS=5, MINUS=6, MULT=7, DIV=8, IDENTIFIER=9, 
		NONNEGATIVE_NUMBER=10, EQUAL=11, COMMA=12, PERIOD=13, COLON=14, AMP=15, 
		PIPE=16, LPAREN=17, RPAREN=18, LBRACE=19, RBRACE=20, LBRACKET=21, RBRACKET=22, 
		LESS_THAN=23, GREATER_THAN=24, SINGLE_QUOTE=25, DOUBLE_QUOTE=26, WS=27, 
		COMMENT=28, LINE_COMMENT=29, PYTHON_COMMENT=30;
	public static final String[] tokenNames = {
		"<INVALID>", "IS_A", "CONSTANT", "'^'", "NOT", "'+'", "'-'", "'*'", "'/'", 
		"IDENTIFIER", "NONNEGATIVE_NUMBER", "'='", "','", "'.'", "':'", "'&'", 
		"'|'", "'('", "')'", "'{'", "'}'", "'['", "']'", "'<'", "'>'", "'''", 
		"'\"'", "WS", "COMMENT", "LINE_COMMENT", "PYTHON_COMMENT"
	};
	public static final int
		RULE_program = 0, RULE_predicate_definition = 1, RULE_predicate = 2, RULE_argumentType = 3, 
		RULE_subtype_definition = 4, RULE_atom = 5, RULE_literal = 6, RULE_term = 7, 
		RULE_variable = 8, RULE_rule_definition = 9, RULE_rule_expression = 10, 
		RULE_disjunctive_clause = 11, RULE_conjunctive_clause = 12, RULE_constraint_definition = 13, 
		RULE_constraint_expression = 14, RULE_constraint_operand = 15, RULE_constraint_literal = 16, 
		RULE_constraint_atom = 17, RULE_constraint_term = 18, RULE_coefficient = 19, 
		RULE_coeff_operator = 20, RULE_selector = 21, RULE_bool_expression = 22, 
		RULE_weight_expression = 23, RULE_exponent_expression = 24, RULE_and = 25, 
		RULE_or = 26, RULE_then = 27, RULE_implied_by = 28, RULE_term_operator = 29, 
		RULE_term_equal = 30, RULE_term_not_equal = 31, RULE_symmetric = 32, RULE_constraint_operator = 33, 
		RULE_less_than_equal = 34, RULE_greater_than_equal = 35, RULE_arithmetic_operator = 36, 
		RULE_linear_operator = 37, RULE_number = 38;
	public static final String[] ruleNames = {
		"program", "predicate_definition", "predicate", "argumentType", "subtype_definition", 
		"atom", "literal", "term", "variable", "rule_definition", "rule_expression", 
		"disjunctive_clause", "conjunctive_clause", "constraint_definition", "constraint_expression", 
		"constraint_operand", "constraint_literal", "constraint_atom", "constraint_term", 
		"coefficient", "coeff_operator", "selector", "bool_expression", "weight_expression", 
		"exponent_expression", "and", "or", "then", "implied_by", "term_operator", 
		"term_equal", "term_not_equal", "symmetric", "constraint_operator", "less_than_equal", 
		"greater_than_equal", "arithmetic_operator", "linear_operator", "number"
	};

	@Override
	public String getGrammarFileName() { return "PSLv2.g4"; }

	@Override
	public String[] getTokenNames() { return tokenNames; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public ATN getATN() { return _ATN; }

	public PSLv2Parser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class ProgramContext extends ParserRuleContext {
		public List<Rule_definitionContext> rule_definition() {
			return getRuleContexts(Rule_definitionContext.class);
		}
		public Predicate_definitionContext predicate_definition(int i) {
			return getRuleContext(Predicate_definitionContext.class,i);
		}
		public List<Predicate_definitionContext> predicate_definition() {
			return getRuleContexts(Predicate_definitionContext.class);
		}
		public List<Constraint_definitionContext> constraint_definition() {
			return getRuleContexts(Constraint_definitionContext.class);
		}
		public List<Subtype_definitionContext> subtype_definition() {
			return getRuleContexts(Subtype_definitionContext.class);
		}
		public Subtype_definitionContext subtype_definition(int i) {
			return getRuleContext(Subtype_definitionContext.class,i);
		}
		public Constraint_definitionContext constraint_definition(int i) {
			return getRuleContext(Constraint_definitionContext.class,i);
		}
		public Rule_definitionContext rule_definition(int i) {
			return getRuleContext(Rule_definitionContext.class,i);
		}
		public ProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_program; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterProgram(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitProgram(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitProgram(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ProgramContext program() throws RecognitionException {
		ProgramContext _localctx = new ProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_program);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(79); 
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,0,_ctx);
			do {
				switch (_alt) {
				case 1:
					{
					{
					setState(78); predicate_definition();
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(81); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,0,_ctx);
			} while ( _alt!=2 && _alt!=-1 );
			setState(86);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,1,_ctx);
			while ( _alt!=2 && _alt!=-1 ) {
				if ( _alt==1 ) {
					{
					{
					setState(83); subtype_definition();
					}
					} 
				}
				setState(88);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,1,_ctx);
			}
			setState(91); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				setState(91);
				switch ( getInterpreter().adaptivePredict(_input,2,_ctx) ) {
				case 1:
					{
					setState(89); rule_definition();
					}
					break;

				case 2:
					{
					setState(90); constraint_definition();
					}
					break;
				}
				}
				setState(93); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << CONSTANT) | (1L << NOT) | (1L << PLUS) | (1L << MINUS) | (1L << IDENTIFIER) | (1L << NONNEGATIVE_NUMBER) | (1L << PIPE) | (1L << LPAREN))) != 0) );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Predicate_definitionContext extends ParserRuleContext {
		public List<TerminalNode> RPAREN() { return getTokens(PSLv2Parser.RPAREN); }
		public TerminalNode RPAREN(int i) {
			return getToken(PSLv2Parser.RPAREN, i);
		}
		public TerminalNode COMMA(int i) {
			return getToken(PSLv2Parser.COMMA, i);
		}
		public TerminalNode IDENTIFIER(int i) {
			return getToken(PSLv2Parser.IDENTIFIER, i);
		}
		public TerminalNode LPAREN(int i) {
			return getToken(PSLv2Parser.LPAREN, i);
		}
		public ArgumentTypeContext argumentType(int i) {
			return getRuleContext(ArgumentTypeContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(PSLv2Parser.COMMA); }
		public List<ArgumentTypeContext> argumentType() {
			return getRuleContexts(ArgumentTypeContext.class);
		}
		public List<TerminalNode> IDENTIFIER() { return getTokens(PSLv2Parser.IDENTIFIER); }
		public List<TerminalNode> LPAREN() { return getTokens(PSLv2Parser.LPAREN); }
		public Predicate_definitionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_predicate_definition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterPredicate_definition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitPredicate_definition(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitPredicate_definition(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Predicate_definitionContext predicate_definition() throws RecognitionException {
		Predicate_definitionContext _localctx = new Predicate_definitionContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_predicate_definition);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(95); match(IDENTIFIER);
			setState(96); match(LPAREN);
			setState(97); argumentType();
			setState(102);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMMA) {
				{
				{
				setState(98); match(COMMA);
				setState(99); argumentType();
				}
				}
				setState(104);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(105); match(RPAREN);
			setState(109);
			switch ( getInterpreter().adaptivePredict(_input,5,_ctx) ) {
			case 1:
				{
				setState(106); match(LPAREN);
				setState(107); match(IDENTIFIER);
				setState(108); match(RPAREN);
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PredicateContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(PSLv2Parser.IDENTIFIER, 0); }
		public PredicateContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_predicate; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterPredicate(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitPredicate(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitPredicate(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PredicateContext predicate() throws RecognitionException {
		PredicateContext _localctx = new PredicateContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_predicate);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(111); match(IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArgumentTypeContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(PSLv2Parser.IDENTIFIER, 0); }
		public ArgumentTypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_argumentType; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterArgumentType(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitArgumentType(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitArgumentType(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ArgumentTypeContext argumentType() throws RecognitionException {
		ArgumentTypeContext _localctx = new ArgumentTypeContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_argumentType);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(113); match(IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Subtype_definitionContext extends ParserRuleContext {
		public ArgumentTypeContext argumentType(int i) {
			return getRuleContext(ArgumentTypeContext.class,i);
		}
		public List<ArgumentTypeContext> argumentType() {
			return getRuleContexts(ArgumentTypeContext.class);
		}
		public TerminalNode IS_A() { return getToken(PSLv2Parser.IS_A, 0); }
		public Subtype_definitionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_subtype_definition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterSubtype_definition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitSubtype_definition(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitSubtype_definition(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Subtype_definitionContext subtype_definition() throws RecognitionException {
		Subtype_definitionContext _localctx = new Subtype_definitionContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_subtype_definition);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(115); argumentType();
			setState(116); match(IS_A);
			setState(117); argumentType();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AtomContext extends ParserRuleContext {
		public TerminalNode RPAREN() { return getToken(PSLv2Parser.RPAREN, 0); }
		public Term_operatorContext term_operator() {
			return getRuleContext(Term_operatorContext.class,0);
		}
		public TerminalNode COMMA(int i) {
			return getToken(PSLv2Parser.COMMA, i);
		}
		public List<TermContext> term() {
			return getRuleContexts(TermContext.class);
		}
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public List<TerminalNode> COMMA() { return getTokens(PSLv2Parser.COMMA); }
		public TermContext term(int i) {
			return getRuleContext(TermContext.class,i);
		}
		public TerminalNode LPAREN() { return getToken(PSLv2Parser.LPAREN, 0); }
		public AtomContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_atom; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterAtom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitAtom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitAtom(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AtomContext atom() throws RecognitionException {
		AtomContext _localctx = new AtomContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_atom);
		int _la;
		try {
			setState(135);
			switch ( getInterpreter().adaptivePredict(_input,7,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(119); predicate();
				setState(120); match(LPAREN);
				setState(121); term();
				setState(126);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(122); match(COMMA);
					setState(123); term();
					}
					}
					setState(128);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(129); match(RPAREN);
				}
				break;

			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(131); term();
				setState(132); term_operator();
				setState(133); term();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LiteralContext extends ParserRuleContext {
		public AtomContext atom() {
			return getRuleContext(AtomContext.class,0);
		}
		public TerminalNode NOT() { return getToken(PSLv2Parser.NOT, 0); }
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public LiteralContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterLiteral(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitLiteral(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitLiteral(this);
			else return visitor.visitChildren(this);
		}
	}

	public final LiteralContext literal() throws RecognitionException {
		LiteralContext _localctx = new LiteralContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_literal);
		try {
			setState(140);
			switch (_input.LA(1)) {
			case CONSTANT:
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(137); atom();
				}
				break;
			case NOT:
				enterOuterAlt(_localctx, 2);
				{
				setState(138); match(NOT);
				setState(139); literal();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TermContext extends ParserRuleContext {
		public TerminalNode CONSTANT() { return getToken(PSLv2Parser.CONSTANT, 0); }
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public TermContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_term; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterTerm(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitTerm(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitTerm(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TermContext term() throws RecognitionException {
		TermContext _localctx = new TermContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_term);
		try {
			setState(144);
			switch (_input.LA(1)) {
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(142); variable();
				}
				break;
			case CONSTANT:
				enterOuterAlt(_localctx, 2);
				{
				setState(143); match(CONSTANT);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VariableContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(PSLv2Parser.IDENTIFIER, 0); }
		public VariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterVariable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitVariable(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitVariable(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VariableContext variable() throws RecognitionException {
		VariableContext _localctx = new VariableContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_variable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(146); match(IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Rule_definitionContext extends ParserRuleContext {
		public Exponent_expressionContext exponent_expression() {
			return getRuleContext(Exponent_expressionContext.class,0);
		}
		public TerminalNode PERIOD() { return getToken(PSLv2Parser.PERIOD, 0); }
		public Rule_expressionContext rule_expression() {
			return getRuleContext(Rule_expressionContext.class,0);
		}
		public Weight_expressionContext weight_expression() {
			return getRuleContext(Weight_expressionContext.class,0);
		}
		public Rule_definitionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rule_definition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterRule_definition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitRule_definition(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitRule_definition(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Rule_definitionContext rule_definition() throws RecognitionException {
		Rule_definitionContext _localctx = new Rule_definitionContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_rule_definition);
		try {
			setState(156);
			switch (_input.LA(1)) {
			case NONNEGATIVE_NUMBER:
				enterOuterAlt(_localctx, 1);
				{
				setState(148); weight_expression();
				setState(149); rule_expression();
				setState(151);
				switch ( getInterpreter().adaptivePredict(_input,10,_ctx) ) {
				case 1:
					{
					setState(150); exponent_expression();
					}
					break;
				}
				}
				break;
			case CONSTANT:
			case NOT:
			case IDENTIFIER:
				enterOuterAlt(_localctx, 2);
				{
				setState(153); rule_expression();
				setState(154); match(PERIOD);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Rule_expressionContext extends ParserRuleContext {
		public Implied_byContext implied_by() {
			return getRuleContext(Implied_byContext.class,0);
		}
		public ThenContext then() {
			return getRuleContext(ThenContext.class,0);
		}
		public Conjunctive_clauseContext conjunctive_clause() {
			return getRuleContext(Conjunctive_clauseContext.class,0);
		}
		public Disjunctive_clauseContext disjunctive_clause() {
			return getRuleContext(Disjunctive_clauseContext.class,0);
		}
		public Rule_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rule_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterRule_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitRule_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitRule_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Rule_expressionContext rule_expression() throws RecognitionException {
		Rule_expressionContext _localctx = new Rule_expressionContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_rule_expression);
		try {
			setState(167);
			switch ( getInterpreter().adaptivePredict(_input,12,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(158); disjunctive_clause();
				}
				break;

			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(159); disjunctive_clause();
				setState(160); implied_by();
				setState(161); conjunctive_clause();
				}
				break;

			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(163); conjunctive_clause();
				setState(164); then();
				setState(165); disjunctive_clause();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Disjunctive_clauseContext extends ParserRuleContext {
		public LiteralContext literal(int i) {
			return getRuleContext(LiteralContext.class,i);
		}
		public List<OrContext> or() {
			return getRuleContexts(OrContext.class);
		}
		public OrContext or(int i) {
			return getRuleContext(OrContext.class,i);
		}
		public List<LiteralContext> literal() {
			return getRuleContexts(LiteralContext.class);
		}
		public Disjunctive_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_disjunctive_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterDisjunctive_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitDisjunctive_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitDisjunctive_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Disjunctive_clauseContext disjunctive_clause() throws RecognitionException {
		Disjunctive_clauseContext _localctx = new Disjunctive_clauseContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_disjunctive_clause);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(169); literal();
			setState(175);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,13,_ctx);
			while ( _alt!=2 && _alt!=-1 ) {
				if ( _alt==1 ) {
					{
					{
					setState(170); or();
					setState(171); literal();
					}
					} 
				}
				setState(177);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,13,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Conjunctive_clauseContext extends ParserRuleContext {
		public LiteralContext literal(int i) {
			return getRuleContext(LiteralContext.class,i);
		}
		public AndContext and(int i) {
			return getRuleContext(AndContext.class,i);
		}
		public List<AndContext> and() {
			return getRuleContexts(AndContext.class);
		}
		public List<LiteralContext> literal() {
			return getRuleContexts(LiteralContext.class);
		}
		public Conjunctive_clauseContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_conjunctive_clause; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterConjunctive_clause(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitConjunctive_clause(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitConjunctive_clause(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Conjunctive_clauseContext conjunctive_clause() throws RecognitionException {
		Conjunctive_clauseContext _localctx = new Conjunctive_clauseContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_conjunctive_clause);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(178); literal();
			setState(184);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==AMP) {
				{
				{
				setState(179); and();
				setState(180); literal();
				}
				}
				setState(186);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Constraint_definitionContext extends ParserRuleContext {
		public List<SelectorContext> selector() {
			return getRuleContexts(SelectorContext.class);
		}
		public Exponent_expressionContext exponent_expression() {
			return getRuleContext(Exponent_expressionContext.class,0);
		}
		public SelectorContext selector(int i) {
			return getRuleContext(SelectorContext.class,i);
		}
		public Constraint_expressionContext constraint_expression() {
			return getRuleContext(Constraint_expressionContext.class,0);
		}
		public TerminalNode PERIOD() { return getToken(PSLv2Parser.PERIOD, 0); }
		public Weight_expressionContext weight_expression() {
			return getRuleContext(Weight_expressionContext.class,0);
		}
		public Constraint_definitionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constraint_definition; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterConstraint_definition(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitConstraint_definition(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitConstraint_definition(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Constraint_definitionContext constraint_definition() throws RecognitionException {
		Constraint_definitionContext _localctx = new Constraint_definitionContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_constraint_definition);
		int _la;
		try {
			setState(206);
			switch ( getInterpreter().adaptivePredict(_input,18,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(187); weight_expression();
				setState(188); constraint_expression();
				setState(190);
				switch ( getInterpreter().adaptivePredict(_input,15,_ctx) ) {
				case 1:
					{
					setState(189); exponent_expression();
					}
					break;
				}
				setState(195);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==LBRACE) {
					{
					{
					setState(192); selector();
					}
					}
					setState(197);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;

			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(198); constraint_expression();
				setState(199); match(PERIOD);
				setState(203);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==LBRACE) {
					{
					{
					setState(200); selector();
					}
					}
					setState(205);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Constraint_expressionContext extends ParserRuleContext {
		public Constraint_operandContext constraint_operand(int i) {
			return getRuleContext(Constraint_operandContext.class,i);
		}
		public List<Linear_operatorContext> linear_operator() {
			return getRuleContexts(Linear_operatorContext.class);
		}
		public Constraint_operatorContext constraint_operator() {
			return getRuleContext(Constraint_operatorContext.class,0);
		}
		public List<Constraint_operandContext> constraint_operand() {
			return getRuleContexts(Constraint_operandContext.class);
		}
		public Linear_operatorContext linear_operator(int i) {
			return getRuleContext(Linear_operatorContext.class,i);
		}
		public Constraint_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constraint_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterConstraint_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitConstraint_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitConstraint_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Constraint_expressionContext constraint_expression() throws RecognitionException {
		Constraint_expressionContext _localctx = new Constraint_expressionContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_constraint_expression);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(208); constraint_operand();
			setState(214);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==PLUS || _la==MINUS) {
				{
				{
				setState(209); linear_operator();
				setState(210); constraint_operand();
				}
				}
				setState(216);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(217); constraint_operator();
			setState(218); constraint_operand();
			setState(224);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,20,_ctx);
			while ( _alt!=2 && _alt!=-1 ) {
				if ( _alt==1 ) {
					{
					{
					setState(219); linear_operator();
					setState(220); constraint_operand();
					}
					} 
				}
				setState(226);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,20,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Constraint_operandContext extends ParserRuleContext {
		public List<CoefficientContext> coefficient() {
			return getRuleContexts(CoefficientContext.class);
		}
		public TerminalNode MULT() { return getToken(PSLv2Parser.MULT, 0); }
		public TerminalNode DIV() { return getToken(PSLv2Parser.DIV, 0); }
		public Constraint_literalContext constraint_literal() {
			return getRuleContext(Constraint_literalContext.class,0);
		}
		public CoefficientContext coefficient(int i) {
			return getRuleContext(CoefficientContext.class,i);
		}
		public Constraint_operandContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constraint_operand; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterConstraint_operand(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitConstraint_operand(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitConstraint_operand(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Constraint_operandContext constraint_operand() throws RecognitionException {
		Constraint_operandContext _localctx = new Constraint_operandContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_constraint_operand);
		int _la;
		try {
			setState(239);
			switch ( getInterpreter().adaptivePredict(_input,24,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(231);
				switch ( getInterpreter().adaptivePredict(_input,22,_ctx) ) {
				case 1:
					{
					setState(227); coefficient(0);
					setState(229);
					_la = _input.LA(1);
					if (_la==MULT) {
						{
						setState(228); match(MULT);
						}
					}

					}
					break;
				}
				setState(233); constraint_literal();
				setState(236);
				_la = _input.LA(1);
				if (_la==DIV) {
					{
					setState(234); match(DIV);
					setState(235); coefficient(0);
					}
				}

				}
				break;

			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(238); coefficient(0);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Constraint_literalContext extends ParserRuleContext {
		public Constraint_atomContext constraint_atom() {
			return getRuleContext(Constraint_atomContext.class,0);
		}
		public TerminalNode NOT() { return getToken(PSLv2Parser.NOT, 0); }
		public Constraint_literalContext constraint_literal() {
			return getRuleContext(Constraint_literalContext.class,0);
		}
		public Constraint_literalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constraint_literal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterConstraint_literal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitConstraint_literal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitConstraint_literal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Constraint_literalContext constraint_literal() throws RecognitionException {
		Constraint_literalContext _localctx = new Constraint_literalContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_constraint_literal);
		try {
			setState(244);
			switch (_input.LA(1)) {
			case CONSTANT:
			case PLUS:
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(241); constraint_atom();
				}
				break;
			case NOT:
				enterOuterAlt(_localctx, 2);
				{
				setState(242); match(NOT);
				setState(243); constraint_literal();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Constraint_atomContext extends ParserRuleContext {
		public TerminalNode RPAREN() { return getToken(PSLv2Parser.RPAREN, 0); }
		public Term_operatorContext term_operator() {
			return getRuleContext(Term_operatorContext.class,0);
		}
		public TerminalNode COMMA(int i) {
			return getToken(PSLv2Parser.COMMA, i);
		}
		public PredicateContext predicate() {
			return getRuleContext(PredicateContext.class,0);
		}
		public List<TerminalNode> COMMA() { return getTokens(PSLv2Parser.COMMA); }
		public Constraint_termContext constraint_term(int i) {
			return getRuleContext(Constraint_termContext.class,i);
		}
		public List<Constraint_termContext> constraint_term() {
			return getRuleContexts(Constraint_termContext.class);
		}
		public TerminalNode LPAREN() { return getToken(PSLv2Parser.LPAREN, 0); }
		public Constraint_atomContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constraint_atom; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterConstraint_atom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitConstraint_atom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitConstraint_atom(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Constraint_atomContext constraint_atom() throws RecognitionException {
		Constraint_atomContext _localctx = new Constraint_atomContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_constraint_atom);
		int _la;
		try {
			setState(262);
			switch ( getInterpreter().adaptivePredict(_input,27,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(246); predicate();
				setState(247); match(LPAREN);
				setState(248); constraint_term();
				setState(253);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(249); match(COMMA);
					setState(250); constraint_term();
					}
					}
					setState(255);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(256); match(RPAREN);
				}
				break;

			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(258); constraint_term();
				setState(259); term_operator();
				setState(260); constraint_term();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Constraint_termContext extends ParserRuleContext {
		public TerminalNode PLUS() { return getToken(PSLv2Parser.PLUS, 0); }
		public TermContext term() {
			return getRuleContext(TermContext.class,0);
		}
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public Constraint_termContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constraint_term; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterConstraint_term(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitConstraint_term(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitConstraint_term(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Constraint_termContext constraint_term() throws RecognitionException {
		Constraint_termContext _localctx = new Constraint_termContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_constraint_term);
		try {
			setState(267);
			switch (_input.LA(1)) {
			case CONSTANT:
			case IDENTIFIER:
				enterOuterAlt(_localctx, 1);
				{
				setState(264); term();
				}
				break;
			case PLUS:
				enterOuterAlt(_localctx, 2);
				{
				setState(265); match(PLUS);
				setState(266); variable();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CoefficientContext extends ParserRuleContext {
		public int _p;
		public TerminalNode LBRACKET() { return getToken(PSLv2Parser.LBRACKET, 0); }
		public List<CoefficientContext> coefficient() {
			return getRuleContexts(CoefficientContext.class);
		}
		public TerminalNode RPAREN() { return getToken(PSLv2Parser.RPAREN, 0); }
		public List<TerminalNode> COMMA() { return getTokens(PSLv2Parser.COMMA); }
		public Arithmetic_operatorContext arithmetic_operator() {
			return getRuleContext(Arithmetic_operatorContext.class,0);
		}
		public NumberContext number() {
			return getRuleContext(NumberContext.class,0);
		}
		public CoefficientContext coefficient(int i) {
			return getRuleContext(CoefficientContext.class,i);
		}
		public Coeff_operatorContext coeff_operator() {
			return getRuleContext(Coeff_operatorContext.class,0);
		}
		public List<TerminalNode> PIPE() { return getTokens(PSLv2Parser.PIPE); }
		public TerminalNode COMMA(int i) {
			return getToken(PSLv2Parser.COMMA, i);
		}
		public TerminalNode PIPE(int i) {
			return getToken(PSLv2Parser.PIPE, i);
		}
		public TerminalNode RBRACKET() { return getToken(PSLv2Parser.RBRACKET, 0); }
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(PSLv2Parser.LPAREN, 0); }
		public CoefficientContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public CoefficientContext(ParserRuleContext parent, int invokingState, int _p) {
			super(parent, invokingState);
			this._p = _p;
		}
		@Override public int getRuleIndex() { return RULE_coefficient; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterCoefficient(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitCoefficient(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitCoefficient(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CoefficientContext coefficient(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		CoefficientContext _localctx = new CoefficientContext(_ctx, _parentState, _p);
		CoefficientContext _prevctx = _localctx;
		int _startState = 38;
		enterRecursionRule(_localctx, RULE_coefficient);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(290);
			switch (_input.LA(1)) {
			case MINUS:
			case NONNEGATIVE_NUMBER:
				{
				setState(270); number();
				}
				break;
			case PIPE:
				{
				setState(271); match(PIPE);
				setState(272); variable();
				setState(273); match(PIPE);
				}
				break;
			case IDENTIFIER:
				{
				setState(275); coeff_operator();
				setState(276); match(LBRACKET);
				setState(277); coefficient(0);
				setState(280); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(278); match(COMMA);
					setState(279); coefficient(0);
					}
					}
					setState(282); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==COMMA );
				setState(284); match(RBRACKET);
				}
				break;
			case LPAREN:
				{
				setState(286); match(LPAREN);
				setState(287); coefficient(0);
				setState(288); match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(298);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,31,_ctx);
			while ( _alt!=2 && _alt!=-1 ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new CoefficientContext(_parentctx, _parentState, _p);
					pushNewRecursionContext(_localctx, _startState, RULE_coefficient);
					setState(292);
					if (!(3 >= _localctx._p)) throw new FailedPredicateException(this, "3 >= $_p");
					setState(293); arithmetic_operator();
					setState(294); coefficient(0);
					}
					} 
				}
				setState(300);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,31,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class Coeff_operatorContext extends ParserRuleContext {
		public TerminalNode IDENTIFIER() { return getToken(PSLv2Parser.IDENTIFIER, 0); }
		public Coeff_operatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_coeff_operator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterCoeff_operator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitCoeff_operator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitCoeff_operator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Coeff_operatorContext coeff_operator() throws RecognitionException {
		Coeff_operatorContext _localctx = new Coeff_operatorContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_coeff_operator);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(301); match(IDENTIFIER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SelectorContext extends ParserRuleContext {
		public TerminalNode COLON() { return getToken(PSLv2Parser.COLON, 0); }
		public Bool_expressionContext bool_expression() {
			return getRuleContext(Bool_expressionContext.class,0);
		}
		public TerminalNode RBRACE() { return getToken(PSLv2Parser.RBRACE, 0); }
		public VariableContext variable() {
			return getRuleContext(VariableContext.class,0);
		}
		public TerminalNode LBRACE() { return getToken(PSLv2Parser.LBRACE, 0); }
		public SelectorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_selector; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterSelector(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitSelector(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitSelector(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SelectorContext selector() throws RecognitionException {
		SelectorContext _localctx = new SelectorContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_selector);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(303); match(LBRACE);
			setState(304); variable();
			setState(305); match(COLON);
			setState(306); bool_expression(0);
			setState(307); match(RBRACE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Bool_expressionContext extends ParserRuleContext {
		public int _p;
		public Bool_expressionContext bool_expression(int i) {
			return getRuleContext(Bool_expressionContext.class,i);
		}
		public TerminalNode RPAREN() { return getToken(PSLv2Parser.RPAREN, 0); }
		public List<Bool_expressionContext> bool_expression() {
			return getRuleContexts(Bool_expressionContext.class);
		}
		public OrContext or() {
			return getRuleContext(OrContext.class,0);
		}
		public TerminalNode LPAREN() { return getToken(PSLv2Parser.LPAREN, 0); }
		public AndContext and() {
			return getRuleContext(AndContext.class,0);
		}
		public LiteralContext literal() {
			return getRuleContext(LiteralContext.class,0);
		}
		public Bool_expressionContext(ParserRuleContext parent, int invokingState) { super(parent, invokingState); }
		public Bool_expressionContext(ParserRuleContext parent, int invokingState, int _p) {
			super(parent, invokingState);
			this._p = _p;
		}
		@Override public int getRuleIndex() { return RULE_bool_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterBool_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitBool_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitBool_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Bool_expressionContext bool_expression(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		Bool_expressionContext _localctx = new Bool_expressionContext(_ctx, _parentState, _p);
		Bool_expressionContext _prevctx = _localctx;
		int _startState = 44;
		enterRecursionRule(_localctx, RULE_bool_expression);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(315);
			switch (_input.LA(1)) {
			case CONSTANT:
			case NOT:
			case IDENTIFIER:
				{
				setState(310); literal();
				}
				break;
			case LPAREN:
				{
				setState(311); match(LPAREN);
				setState(312); bool_expression(0);
				setState(313); match(RPAREN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(327);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,34,_ctx);
			while ( _alt!=2 && _alt!=-1 ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(325);
					switch ( getInterpreter().adaptivePredict(_input,33,_ctx) ) {
					case 1:
						{
						_localctx = new Bool_expressionContext(_parentctx, _parentState, _p);
						pushNewRecursionContext(_localctx, _startState, RULE_bool_expression);
						setState(317);
						if (!(3 >= _localctx._p)) throw new FailedPredicateException(this, "3 >= $_p");
						setState(318); or();
						setState(319); bool_expression(0);
						}
						break;

					case 2:
						{
						_localctx = new Bool_expressionContext(_parentctx, _parentState, _p);
						pushNewRecursionContext(_localctx, _startState, RULE_bool_expression);
						setState(321);
						if (!(2 >= _localctx._p)) throw new FailedPredicateException(this, "2 >= $_p");
						setState(322); and();
						setState(323); bool_expression(0);
						}
						break;
					}
					} 
				}
				setState(329);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,34,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class Weight_expressionContext extends ParserRuleContext {
		public TerminalNode COLON() { return getToken(PSLv2Parser.COLON, 0); }
		public TerminalNode NONNEGATIVE_NUMBER() { return getToken(PSLv2Parser.NONNEGATIVE_NUMBER, 0); }
		public Weight_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_weight_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterWeight_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitWeight_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitWeight_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Weight_expressionContext weight_expression() throws RecognitionException {
		Weight_expressionContext _localctx = new Weight_expressionContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_weight_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(330); match(NONNEGATIVE_NUMBER);
			setState(332);
			_la = _input.LA(1);
			if (_la==COLON) {
				{
				setState(331); match(COLON);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Exponent_expressionContext extends ParserRuleContext {
		public TerminalNode NONNEGATIVE_NUMBER() { return getToken(PSLv2Parser.NONNEGATIVE_NUMBER, 0); }
		public TerminalNode CARET() { return getToken(PSLv2Parser.CARET, 0); }
		public Exponent_expressionContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_exponent_expression; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterExponent_expression(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitExponent_expression(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitExponent_expression(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Exponent_expressionContext exponent_expression() throws RecognitionException {
		Exponent_expressionContext _localctx = new Exponent_expressionContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_exponent_expression);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(335);
			_la = _input.LA(1);
			if (_la==CARET) {
				{
				setState(334); match(CARET);
				}
			}

			setState(337); match(NONNEGATIVE_NUMBER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AndContext extends ParserRuleContext {
		public TerminalNode AMP(int i) {
			return getToken(PSLv2Parser.AMP, i);
		}
		public List<TerminalNode> AMP() { return getTokens(PSLv2Parser.AMP); }
		public AndContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_and; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterAnd(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitAnd(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitAnd(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AndContext and() throws RecognitionException {
		AndContext _localctx = new AndContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_and);
		try {
			setState(342);
			switch ( getInterpreter().adaptivePredict(_input,37,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(339); match(AMP);
				}
				break;

			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(340); match(AMP);
				setState(341); match(AMP);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OrContext extends ParserRuleContext {
		public List<TerminalNode> PIPE() { return getTokens(PSLv2Parser.PIPE); }
		public TerminalNode PIPE(int i) {
			return getToken(PSLv2Parser.PIPE, i);
		}
		public OrContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_or; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterOr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitOr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitOr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OrContext or() throws RecognitionException {
		OrContext _localctx = new OrContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_or);
		try {
			setState(347);
			switch ( getInterpreter().adaptivePredict(_input,38,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(344); match(PIPE);
				}
				break;

			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(345); match(PIPE);
				setState(346); match(PIPE);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ThenContext extends ParserRuleContext {
		public List<TerminalNode> GREATER_THAN() { return getTokens(PSLv2Parser.GREATER_THAN); }
		public TerminalNode MINUS() { return getToken(PSLv2Parser.MINUS, 0); }
		public TerminalNode GREATER_THAN(int i) {
			return getToken(PSLv2Parser.GREATER_THAN, i);
		}
		public ThenContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_then; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterThen(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitThen(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitThen(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ThenContext then() throws RecognitionException {
		ThenContext _localctx = new ThenContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_then);
		try {
			setState(353);
			switch (_input.LA(1)) {
			case GREATER_THAN:
				enterOuterAlt(_localctx, 1);
				{
				setState(349); match(GREATER_THAN);
				setState(350); match(GREATER_THAN);
				}
				break;
			case MINUS:
				enterOuterAlt(_localctx, 2);
				{
				setState(351); match(MINUS);
				setState(352); match(GREATER_THAN);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Implied_byContext extends ParserRuleContext {
		public TerminalNode LESS_THAN(int i) {
			return getToken(PSLv2Parser.LESS_THAN, i);
		}
		public TerminalNode MINUS() { return getToken(PSLv2Parser.MINUS, 0); }
		public List<TerminalNode> LESS_THAN() { return getTokens(PSLv2Parser.LESS_THAN); }
		public Implied_byContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_implied_by; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterImplied_by(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitImplied_by(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitImplied_by(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Implied_byContext implied_by() throws RecognitionException {
		Implied_byContext _localctx = new Implied_byContext(_ctx, getState());
		enterRule(_localctx, 56, RULE_implied_by);
		try {
			setState(359);
			switch ( getInterpreter().adaptivePredict(_input,40,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(355); match(LESS_THAN);
				setState(356); match(LESS_THAN);
				}
				break;

			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(357); match(LESS_THAN);
				setState(358); match(MINUS);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Term_operatorContext extends ParserRuleContext {
		public Term_not_equalContext term_not_equal() {
			return getRuleContext(Term_not_equalContext.class,0);
		}
		public Term_equalContext term_equal() {
			return getRuleContext(Term_equalContext.class,0);
		}
		public SymmetricContext symmetric() {
			return getRuleContext(SymmetricContext.class,0);
		}
		public Term_operatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_term_operator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterTerm_operator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitTerm_operator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitTerm_operator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Term_operatorContext term_operator() throws RecognitionException {
		Term_operatorContext _localctx = new Term_operatorContext(_ctx, getState());
		enterRule(_localctx, 58, RULE_term_operator);
		try {
			setState(364);
			switch (_input.LA(1)) {
			case EQUAL:
				enterOuterAlt(_localctx, 1);
				{
				setState(361); term_equal();
				}
				break;
			case NOT:
				enterOuterAlt(_localctx, 2);
				{
				setState(362); term_not_equal();
				}
				break;
			case CARET:
				enterOuterAlt(_localctx, 3);
				{
				setState(363); symmetric();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Term_equalContext extends ParserRuleContext {
		public TerminalNode EQUAL(int i) {
			return getToken(PSLv2Parser.EQUAL, i);
		}
		public List<TerminalNode> EQUAL() { return getTokens(PSLv2Parser.EQUAL); }
		public Term_equalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_term_equal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterTerm_equal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitTerm_equal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitTerm_equal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Term_equalContext term_equal() throws RecognitionException {
		Term_equalContext _localctx = new Term_equalContext(_ctx, getState());
		enterRule(_localctx, 60, RULE_term_equal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(366); match(EQUAL);
			setState(367); match(EQUAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Term_not_equalContext extends ParserRuleContext {
		public TerminalNode NOT() { return getToken(PSLv2Parser.NOT, 0); }
		public TerminalNode EQUAL() { return getToken(PSLv2Parser.EQUAL, 0); }
		public Term_not_equalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_term_not_equal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterTerm_not_equal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitTerm_not_equal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitTerm_not_equal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Term_not_equalContext term_not_equal() throws RecognitionException {
		Term_not_equalContext _localctx = new Term_not_equalContext(_ctx, getState());
		enterRule(_localctx, 62, RULE_term_not_equal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(369); match(NOT);
			setState(370); match(EQUAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SymmetricContext extends ParserRuleContext {
		public TerminalNode CARET() { return getToken(PSLv2Parser.CARET, 0); }
		public SymmetricContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_symmetric; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterSymmetric(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitSymmetric(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitSymmetric(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SymmetricContext symmetric() throws RecognitionException {
		SymmetricContext _localctx = new SymmetricContext(_ctx, getState());
		enterRule(_localctx, 64, RULE_symmetric);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(372); match(CARET);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Constraint_operatorContext extends ParserRuleContext {
		public Greater_than_equalContext greater_than_equal() {
			return getRuleContext(Greater_than_equalContext.class,0);
		}
		public Less_than_equalContext less_than_equal() {
			return getRuleContext(Less_than_equalContext.class,0);
		}
		public TerminalNode EQUAL() { return getToken(PSLv2Parser.EQUAL, 0); }
		public Constraint_operatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_constraint_operator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterConstraint_operator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitConstraint_operator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitConstraint_operator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Constraint_operatorContext constraint_operator() throws RecognitionException {
		Constraint_operatorContext _localctx = new Constraint_operatorContext(_ctx, getState());
		enterRule(_localctx, 66, RULE_constraint_operator);
		try {
			setState(377);
			switch (_input.LA(1)) {
			case LESS_THAN:
				enterOuterAlt(_localctx, 1);
				{
				setState(374); less_than_equal();
				}
				break;
			case GREATER_THAN:
				enterOuterAlt(_localctx, 2);
				{
				setState(375); greater_than_equal();
				}
				break;
			case EQUAL:
				enterOuterAlt(_localctx, 3);
				{
				setState(376); match(EQUAL);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Less_than_equalContext extends ParserRuleContext {
		public TerminalNode EQUAL() { return getToken(PSLv2Parser.EQUAL, 0); }
		public TerminalNode LESS_THAN() { return getToken(PSLv2Parser.LESS_THAN, 0); }
		public Less_than_equalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_less_than_equal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterLess_than_equal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitLess_than_equal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitLess_than_equal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Less_than_equalContext less_than_equal() throws RecognitionException {
		Less_than_equalContext _localctx = new Less_than_equalContext(_ctx, getState());
		enterRule(_localctx, 68, RULE_less_than_equal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(379); match(LESS_THAN);
			setState(380); match(EQUAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Greater_than_equalContext extends ParserRuleContext {
		public TerminalNode GREATER_THAN() { return getToken(PSLv2Parser.GREATER_THAN, 0); }
		public TerminalNode EQUAL() { return getToken(PSLv2Parser.EQUAL, 0); }
		public Greater_than_equalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_greater_than_equal; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterGreater_than_equal(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitGreater_than_equal(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitGreater_than_equal(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Greater_than_equalContext greater_than_equal() throws RecognitionException {
		Greater_than_equalContext _localctx = new Greater_than_equalContext(_ctx, getState());
		enterRule(_localctx, 70, RULE_greater_than_equal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(382); match(GREATER_THAN);
			setState(383); match(EQUAL);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Arithmetic_operatorContext extends ParserRuleContext {
		public TerminalNode PLUS() { return getToken(PSLv2Parser.PLUS, 0); }
		public TerminalNode DIV() { return getToken(PSLv2Parser.DIV, 0); }
		public TerminalNode MULT() { return getToken(PSLv2Parser.MULT, 0); }
		public TerminalNode MINUS() { return getToken(PSLv2Parser.MINUS, 0); }
		public Arithmetic_operatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arithmetic_operator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterArithmetic_operator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitArithmetic_operator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitArithmetic_operator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Arithmetic_operatorContext arithmetic_operator() throws RecognitionException {
		Arithmetic_operatorContext _localctx = new Arithmetic_operatorContext(_ctx, getState());
		enterRule(_localctx, 72, RULE_arithmetic_operator);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(385);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << PLUS) | (1L << MINUS) | (1L << MULT) | (1L << DIV))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			consume();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Linear_operatorContext extends ParserRuleContext {
		public TerminalNode PLUS() { return getToken(PSLv2Parser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(PSLv2Parser.MINUS, 0); }
		public Linear_operatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_linear_operator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterLinear_operator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitLinear_operator(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitLinear_operator(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Linear_operatorContext linear_operator() throws RecognitionException {
		Linear_operatorContext _localctx = new Linear_operatorContext(_ctx, getState());
		enterRule(_localctx, 74, RULE_linear_operator);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(387);
			_la = _input.LA(1);
			if ( !(_la==PLUS || _la==MINUS) ) {
			_errHandler.recoverInline(this);
			}
			consume();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class NumberContext extends ParserRuleContext {
		public TerminalNode MINUS() { return getToken(PSLv2Parser.MINUS, 0); }
		public TerminalNode NONNEGATIVE_NUMBER() { return getToken(PSLv2Parser.NONNEGATIVE_NUMBER, 0); }
		public NumberContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_number; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).enterNumber(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PSLv2Listener ) ((PSLv2Listener)listener).exitNumber(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PSLv2Visitor ) return ((PSLv2Visitor<? extends T>)visitor).visitNumber(this);
			else return visitor.visitChildren(this);
		}
	}

	public final NumberContext number() throws RecognitionException {
		NumberContext _localctx = new NumberContext(_ctx, getState());
		enterRule(_localctx, 76, RULE_number);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(390);
			_la = _input.LA(1);
			if (_la==MINUS) {
				{
				setState(389); match(MINUS);
				}
			}

			setState(392); match(NONNEGATIVE_NUMBER);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 19: return coefficient_sempred((CoefficientContext)_localctx, predIndex);

		case 22: return bool_expression_sempred((Bool_expressionContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean coefficient_sempred(CoefficientContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0: return 3 >= _localctx._p;
		}
		return true;
	}
	private boolean bool_expression_sempred(Bool_expressionContext _localctx, int predIndex) {
		switch (predIndex) {
		case 1: return 3 >= _localctx._p;

		case 2: return 2 >= _localctx._p;
		}
		return true;
	}

	public static final String _serializedATN =
		"\2\3 \u018d\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4"+
		"\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20"+
		"\4\21\t\21\4\22\t\22\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27"+
		"\4\30\t\30\4\31\t\31\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36\t\36"+
		"\4\37\t\37\4 \t \4!\t!\4\"\t\"\4#\t#\4$\t$\4%\t%\4&\t&\4\'\t\'\4(\t(\3"+
		"\2\6\2R\n\2\r\2\16\2S\3\2\7\2W\n\2\f\2\16\2Z\13\2\3\2\3\2\6\2^\n\2\r\2"+
		"\16\2_\3\3\3\3\3\3\3\3\3\3\7\3g\n\3\f\3\16\3j\13\3\3\3\3\3\3\3\3\3\5\3"+
		"p\n\3\3\4\3\4\3\5\3\5\3\6\3\6\3\6\3\6\3\7\3\7\3\7\3\7\3\7\7\7\177\n\7"+
		"\f\7\16\7\u0082\13\7\3\7\3\7\3\7\3\7\3\7\3\7\5\7\u008a\n\7\3\b\3\b\3\b"+
		"\5\b\u008f\n\b\3\t\3\t\5\t\u0093\n\t\3\n\3\n\3\13\3\13\3\13\5\13\u009a"+
		"\n\13\3\13\3\13\3\13\5\13\u009f\n\13\3\f\3\f\3\f\3\f\3\f\3\f\3\f\3\f\3"+
		"\f\5\f\u00aa\n\f\3\r\3\r\3\r\3\r\7\r\u00b0\n\r\f\r\16\r\u00b3\13\r\3\16"+
		"\3\16\3\16\3\16\7\16\u00b9\n\16\f\16\16\16\u00bc\13\16\3\17\3\17\3\17"+
		"\5\17\u00c1\n\17\3\17\7\17\u00c4\n\17\f\17\16\17\u00c7\13\17\3\17\3\17"+
		"\3\17\7\17\u00cc\n\17\f\17\16\17\u00cf\13\17\5\17\u00d1\n\17\3\20\3\20"+
		"\3\20\3\20\7\20\u00d7\n\20\f\20\16\20\u00da\13\20\3\20\3\20\3\20\3\20"+
		"\3\20\7\20\u00e1\n\20\f\20\16\20\u00e4\13\20\3\21\3\21\5\21\u00e8\n\21"+
		"\5\21\u00ea\n\21\3\21\3\21\3\21\5\21\u00ef\n\21\3\21\5\21\u00f2\n\21\3"+
		"\22\3\22\3\22\5\22\u00f7\n\22\3\23\3\23\3\23\3\23\3\23\7\23\u00fe\n\23"+
		"\f\23\16\23\u0101\13\23\3\23\3\23\3\23\3\23\3\23\3\23\5\23\u0109\n\23"+
		"\3\24\3\24\3\24\5\24\u010e\n\24\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25"+
		"\3\25\3\25\3\25\6\25\u011b\n\25\r\25\16\25\u011c\3\25\3\25\3\25\3\25\3"+
		"\25\3\25\5\25\u0125\n\25\3\25\3\25\3\25\3\25\7\25\u012b\n\25\f\25\16\25"+
		"\u012e\13\25\3\26\3\26\3\27\3\27\3\27\3\27\3\27\3\27\3\30\3\30\3\30\3"+
		"\30\3\30\3\30\5\30\u013e\n\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30"+
		"\7\30\u0148\n\30\f\30\16\30\u014b\13\30\3\31\3\31\5\31\u014f\n\31\3\32"+
		"\5\32\u0152\n\32\3\32\3\32\3\33\3\33\3\33\5\33\u0159\n\33\3\34\3\34\3"+
		"\34\5\34\u015e\n\34\3\35\3\35\3\35\3\35\5\35\u0164\n\35\3\36\3\36\3\36"+
		"\3\36\5\36\u016a\n\36\3\37\3\37\3\37\5\37\u016f\n\37\3 \3 \3 \3!\3!\3"+
		"!\3\"\3\"\3#\3#\3#\5#\u017c\n#\3$\3$\3$\3%\3%\3%\3&\3&\3\'\3\'\3(\5(\u0189"+
		"\n(\3(\3(\3(\2)\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(*,.\60\62"+
		"\64\668:<>@BDFHJLN\2\4\3\7\n\3\7\b\u0196\2Q\3\2\2\2\4a\3\2\2\2\6q\3\2"+
		"\2\2\bs\3\2\2\2\nu\3\2\2\2\f\u0089\3\2\2\2\16\u008e\3\2\2\2\20\u0092\3"+
		"\2\2\2\22\u0094\3\2\2\2\24\u009e\3\2\2\2\26\u00a9\3\2\2\2\30\u00ab\3\2"+
		"\2\2\32\u00b4\3\2\2\2\34\u00d0\3\2\2\2\36\u00d2\3\2\2\2 \u00f1\3\2\2\2"+
		"\"\u00f6\3\2\2\2$\u0108\3\2\2\2&\u010d\3\2\2\2(\u0124\3\2\2\2*\u012f\3"+
		"\2\2\2,\u0131\3\2\2\2.\u013d\3\2\2\2\60\u014c\3\2\2\2\62\u0151\3\2\2\2"+
		"\64\u0158\3\2\2\2\66\u015d\3\2\2\28\u0163\3\2\2\2:\u0169\3\2\2\2<\u016e"+
		"\3\2\2\2>\u0170\3\2\2\2@\u0173\3\2\2\2B\u0176\3\2\2\2D\u017b\3\2\2\2F"+
		"\u017d\3\2\2\2H\u0180\3\2\2\2J\u0183\3\2\2\2L\u0185\3\2\2\2N\u0188\3\2"+
		"\2\2PR\5\4\3\2QP\3\2\2\2RS\3\2\2\2SQ\3\2\2\2ST\3\2\2\2TX\3\2\2\2UW\5\n"+
		"\6\2VU\3\2\2\2WZ\3\2\2\2XV\3\2\2\2XY\3\2\2\2Y]\3\2\2\2ZX\3\2\2\2[^\5\24"+
		"\13\2\\^\5\34\17\2][\3\2\2\2]\\\3\2\2\2^_\3\2\2\2_]\3\2\2\2_`\3\2\2\2"+
		"`\3\3\2\2\2ab\7\13\2\2bc\7\23\2\2ch\5\b\5\2de\7\16\2\2eg\5\b\5\2fd\3\2"+
		"\2\2gj\3\2\2\2hf\3\2\2\2hi\3\2\2\2ik\3\2\2\2jh\3\2\2\2ko\7\24\2\2lm\7"+
		"\23\2\2mn\7\13\2\2np\7\24\2\2ol\3\2\2\2op\3\2\2\2p\5\3\2\2\2qr\7\13\2"+
		"\2r\7\3\2\2\2st\7\13\2\2t\t\3\2\2\2uv\5\b\5\2vw\7\3\2\2wx\5\b\5\2x\13"+
		"\3\2\2\2yz\5\6\4\2z{\7\23\2\2{\u0080\5\20\t\2|}\7\16\2\2}\177\5\20\t\2"+
		"~|\3\2\2\2\177\u0082\3\2\2\2\u0080~\3\2\2\2\u0080\u0081\3\2\2\2\u0081"+
		"\u0083\3\2\2\2\u0082\u0080\3\2\2\2\u0083\u0084\7\24\2\2\u0084\u008a\3"+
		"\2\2\2\u0085\u0086\5\20\t\2\u0086\u0087\5<\37\2\u0087\u0088\5\20\t\2\u0088"+
		"\u008a\3\2\2\2\u0089y\3\2\2\2\u0089\u0085\3\2\2\2\u008a\r\3\2\2\2\u008b"+
		"\u008f\5\f\7\2\u008c\u008d\7\6\2\2\u008d\u008f\5\16\b\2\u008e\u008b\3"+
		"\2\2\2\u008e\u008c\3\2\2\2\u008f\17\3\2\2\2\u0090\u0093\5\22\n\2\u0091"+
		"\u0093\7\4\2\2\u0092\u0090\3\2\2\2\u0092\u0091\3\2\2\2\u0093\21\3\2\2"+
		"\2\u0094\u0095\7\13\2\2\u0095\23\3\2\2\2\u0096\u0097\5\60\31\2\u0097\u0099"+
		"\5\26\f\2\u0098\u009a\5\62\32\2\u0099\u0098\3\2\2\2\u0099\u009a\3\2\2"+
		"\2\u009a\u009f\3\2\2\2\u009b\u009c\5\26\f\2\u009c\u009d\7\17\2\2\u009d"+
		"\u009f\3\2\2\2\u009e\u0096\3\2\2\2\u009e\u009b\3\2\2\2\u009f\25\3\2\2"+
		"\2\u00a0\u00aa\5\30\r\2\u00a1\u00a2\5\30\r\2\u00a2\u00a3\5:\36\2\u00a3"+
		"\u00a4\5\32\16\2\u00a4\u00aa\3\2\2\2\u00a5\u00a6\5\32\16\2\u00a6\u00a7"+
		"\58\35\2\u00a7\u00a8\5\30\r\2\u00a8\u00aa\3\2\2\2\u00a9\u00a0\3\2\2\2"+
		"\u00a9\u00a1\3\2\2\2\u00a9\u00a5\3\2\2\2\u00aa\27\3\2\2\2\u00ab\u00b1"+
		"\5\16\b\2\u00ac\u00ad\5\66\34\2\u00ad\u00ae\5\16\b\2\u00ae\u00b0\3\2\2"+
		"\2\u00af\u00ac\3\2\2\2\u00b0\u00b3\3\2\2\2\u00b1\u00af\3\2\2\2\u00b1\u00b2"+
		"\3\2\2\2\u00b2\31\3\2\2\2\u00b3\u00b1\3\2\2\2\u00b4\u00ba\5\16\b\2\u00b5"+
		"\u00b6\5\64\33\2\u00b6\u00b7\5\16\b\2\u00b7\u00b9\3\2\2\2\u00b8\u00b5"+
		"\3\2\2\2\u00b9\u00bc\3\2\2\2\u00ba\u00b8\3\2\2\2\u00ba\u00bb\3\2\2\2\u00bb"+
		"\33\3\2\2\2\u00bc\u00ba\3\2\2\2\u00bd\u00be\5\60\31\2\u00be\u00c0\5\36"+
		"\20\2\u00bf\u00c1\5\62\32\2\u00c0\u00bf\3\2\2\2\u00c0\u00c1\3\2\2\2\u00c1"+
		"\u00c5\3\2\2\2\u00c2\u00c4\5,\27\2\u00c3\u00c2\3\2\2\2\u00c4\u00c7\3\2"+
		"\2\2\u00c5\u00c3\3\2\2\2\u00c5\u00c6\3\2\2\2\u00c6\u00d1\3\2\2\2\u00c7"+
		"\u00c5\3\2\2\2\u00c8\u00c9\5\36\20\2\u00c9\u00cd\7\17\2\2\u00ca\u00cc"+
		"\5,\27\2\u00cb\u00ca\3\2\2\2\u00cc\u00cf\3\2\2\2\u00cd\u00cb\3\2\2\2\u00cd"+
		"\u00ce\3\2\2\2\u00ce\u00d1\3\2\2\2\u00cf\u00cd\3\2\2\2\u00d0\u00bd\3\2"+
		"\2\2\u00d0\u00c8\3\2\2\2\u00d1\35\3\2\2\2\u00d2\u00d8\5 \21\2\u00d3\u00d4"+
		"\5L\'\2\u00d4\u00d5\5 \21\2\u00d5\u00d7\3\2\2\2\u00d6\u00d3\3\2\2\2\u00d7"+
		"\u00da\3\2\2\2\u00d8\u00d6\3\2\2\2\u00d8\u00d9\3\2\2\2\u00d9\u00db\3\2"+
		"\2\2\u00da\u00d8\3\2\2\2\u00db\u00dc\5D#\2\u00dc\u00e2\5 \21\2\u00dd\u00de"+
		"\5L\'\2\u00de\u00df\5 \21\2\u00df\u00e1\3\2\2\2\u00e0\u00dd\3\2\2\2\u00e1"+
		"\u00e4\3\2\2\2\u00e2\u00e0\3\2\2\2\u00e2\u00e3\3\2\2\2\u00e3\37\3\2\2"+
		"\2\u00e4\u00e2\3\2\2\2\u00e5\u00e7\5(\25\2\u00e6\u00e8\7\t\2\2\u00e7\u00e6"+
		"\3\2\2\2\u00e7\u00e8\3\2\2\2\u00e8\u00ea\3\2\2\2\u00e9\u00e5\3\2\2\2\u00e9"+
		"\u00ea\3\2\2\2\u00ea\u00eb\3\2\2\2\u00eb\u00ee\5\"\22\2\u00ec\u00ed\7"+
		"\n\2\2\u00ed\u00ef\5(\25\2\u00ee\u00ec\3\2\2\2\u00ee\u00ef\3\2\2\2\u00ef"+
		"\u00f2\3\2\2\2\u00f0\u00f2\5(\25\2\u00f1\u00e9\3\2\2\2\u00f1\u00f0\3\2"+
		"\2\2\u00f2!\3\2\2\2\u00f3\u00f7\5$\23\2\u00f4\u00f5\7\6\2\2\u00f5\u00f7"+
		"\5\"\22\2\u00f6\u00f3\3\2\2\2\u00f6\u00f4\3\2\2\2\u00f7#\3\2\2\2\u00f8"+
		"\u00f9\5\6\4\2\u00f9\u00fa\7\23\2\2\u00fa\u00ff\5&\24\2\u00fb\u00fc\7"+
		"\16\2\2\u00fc\u00fe\5&\24\2\u00fd\u00fb\3\2\2\2\u00fe\u0101\3\2\2\2\u00ff"+
		"\u00fd\3\2\2\2\u00ff\u0100\3\2\2\2\u0100\u0102\3\2\2\2\u0101\u00ff\3\2"+
		"\2\2\u0102\u0103\7\24\2\2\u0103\u0109\3\2\2\2\u0104\u0105\5&\24\2\u0105"+
		"\u0106\5<\37\2\u0106\u0107\5&\24\2\u0107\u0109\3\2\2\2\u0108\u00f8\3\2"+
		"\2\2\u0108\u0104\3\2\2\2\u0109%\3\2\2\2\u010a\u010e\5\20\t\2\u010b\u010c"+
		"\7\7\2\2\u010c\u010e\5\22\n\2\u010d\u010a\3\2\2\2\u010d\u010b\3\2\2\2"+
		"\u010e\'\3\2\2\2\u010f\u0110\b\25\1\2\u0110\u0125\5N(\2\u0111\u0112\7"+
		"\22\2\2\u0112\u0113\5\22\n\2\u0113\u0114\7\22\2\2\u0114\u0125\3\2\2\2"+
		"\u0115\u0116\5*\26\2\u0116\u0117\7\27\2\2\u0117\u011a\5(\25\2\u0118\u0119"+
		"\7\16\2\2\u0119\u011b\5(\25\2\u011a\u0118\3\2\2\2\u011b\u011c\3\2\2\2"+
		"\u011c\u011a\3\2\2\2\u011c\u011d\3\2\2\2\u011d\u011e\3\2\2\2\u011e\u011f"+
		"\7\30\2\2\u011f\u0125\3\2\2\2\u0120\u0121\7\23\2\2\u0121\u0122\5(\25\2"+
		"\u0122\u0123\7\24\2\2\u0123\u0125\3\2\2\2\u0124\u010f\3\2\2\2\u0124\u0111"+
		"\3\2\2\2\u0124\u0115\3\2\2\2\u0124\u0120\3\2\2\2\u0125\u012c\3\2\2\2\u0126"+
		"\u0127\6\25\2\3\u0127\u0128\5J&\2\u0128\u0129\5(\25\2\u0129\u012b\3\2"+
		"\2\2\u012a\u0126\3\2\2\2\u012b\u012e\3\2\2\2\u012c\u012a\3\2\2\2\u012c"+
		"\u012d\3\2\2\2\u012d)\3\2\2\2\u012e\u012c\3\2\2\2\u012f\u0130\7\13\2\2"+
		"\u0130+\3\2\2\2\u0131\u0132\7\25\2\2\u0132\u0133\5\22\n\2\u0133\u0134"+
		"\7\20\2\2\u0134\u0135\5.\30\2\u0135\u0136\7\26\2\2\u0136-\3\2\2\2\u0137"+
		"\u0138\b\30\1\2\u0138\u013e\5\16\b\2\u0139\u013a\7\23\2\2\u013a\u013b"+
		"\5.\30\2\u013b\u013c\7\24\2\2\u013c\u013e\3\2\2\2\u013d\u0137\3\2\2\2"+
		"\u013d\u0139\3\2\2\2\u013e\u0149\3\2\2\2\u013f\u0140\6\30\3\3\u0140\u0141"+
		"\5\66\34\2\u0141\u0142\5.\30\2\u0142\u0148\3\2\2\2\u0143\u0144\6\30\4"+
		"\3\u0144\u0145\5\64\33\2\u0145\u0146\5.\30\2\u0146\u0148\3\2\2\2\u0147"+
		"\u013f\3\2\2\2\u0147\u0143\3\2\2\2\u0148\u014b\3\2\2\2\u0149\u0147\3\2"+
		"\2\2\u0149\u014a\3\2\2\2\u014a/\3\2\2\2\u014b\u0149\3\2\2\2\u014c\u014e"+
		"\7\f\2\2\u014d\u014f\7\20\2\2\u014e\u014d\3\2\2\2\u014e\u014f\3\2\2\2"+
		"\u014f\61\3\2\2\2\u0150\u0152\7\5\2\2\u0151\u0150\3\2\2\2\u0151\u0152"+
		"\3\2\2\2\u0152\u0153\3\2\2\2\u0153\u0154\7\f\2\2\u0154\63\3\2\2\2\u0155"+
		"\u0159\7\21\2\2\u0156\u0157\7\21\2\2\u0157\u0159\7\21\2\2\u0158\u0155"+
		"\3\2\2\2\u0158\u0156\3\2\2\2\u0159\65\3\2\2\2\u015a\u015e\7\22\2\2\u015b"+
		"\u015c\7\22\2\2\u015c\u015e\7\22\2\2\u015d\u015a\3\2\2\2\u015d\u015b\3"+
		"\2\2\2\u015e\67\3\2\2\2\u015f\u0160\7\32\2\2\u0160\u0164\7\32\2\2\u0161"+
		"\u0162\7\b\2\2\u0162\u0164\7\32\2\2\u0163\u015f\3\2\2\2\u0163\u0161\3"+
		"\2\2\2\u01649\3\2\2\2\u0165\u0166\7\31\2\2\u0166\u016a\7\31\2\2\u0167"+
		"\u0168\7\31\2\2\u0168\u016a\7\b\2\2\u0169\u0165\3\2\2\2\u0169\u0167\3"+
		"\2\2\2\u016a;\3\2\2\2\u016b\u016f\5> \2\u016c\u016f\5@!\2\u016d\u016f"+
		"\5B\"\2\u016e\u016b\3\2\2\2\u016e\u016c\3\2\2\2\u016e\u016d\3\2\2\2\u016f"+
		"=\3\2\2\2\u0170\u0171\7\r\2\2\u0171\u0172\7\r\2\2\u0172?\3\2\2\2\u0173"+
		"\u0174\7\6\2\2\u0174\u0175\7\r\2\2\u0175A\3\2\2\2\u0176\u0177\7\5\2\2"+
		"\u0177C\3\2\2\2\u0178\u017c\5F$\2\u0179\u017c\5H%\2\u017a\u017c\7\r\2"+
		"\2\u017b\u0178\3\2\2\2\u017b\u0179\3\2\2\2\u017b\u017a\3\2\2\2\u017cE"+
		"\3\2\2\2\u017d\u017e\7\31\2\2\u017e\u017f\7\r\2\2\u017fG\3\2\2\2\u0180"+
		"\u0181\7\32\2\2\u0181\u0182\7\r\2\2\u0182I\3\2\2\2\u0183\u0184\t\2\2\2"+
		"\u0184K\3\2\2\2\u0185\u0186\t\3\2\2\u0186M\3\2\2\2\u0187\u0189\7\b\2\2"+
		"\u0188\u0187\3\2\2\2\u0188\u0189\3\2\2\2\u0189\u018a\3\2\2\2\u018a\u018b"+
		"\7\f\2\2\u018bO\3\2\2\2.SX]_ho\u0080\u0089\u008e\u0092\u0099\u009e\u00a9"+
		"\u00b1\u00ba\u00c0\u00c5\u00cd\u00d0\u00d8\u00e2\u00e7\u00e9\u00ee\u00f1"+
		"\u00f6\u00ff\u0108\u010d\u011c\u0124\u012c\u013d\u0147\u0149\u014e\u0151"+
		"\u0158\u015d\u0163\u0169\u016e\u017b\u0188";
	public static final ATN _ATN =
		ATNSimulator.deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
	}
}