// Generated from /Users/bach/NetBeansProjects/GrammarTester/src/edu/umd/cs/psl/PSLv2.g4 by ANTLR 4.0
package edu.umd.cs.psl;

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.tree.TerminalNode;
import org.antlr.v4.runtime.tree.ErrorNode;

public class PSLv2BaseListener implements PSLv2Listener {
	@Override public void enterCoefficient(PSLv2Parser.CoefficientContext ctx) { }
	@Override public void exitCoefficient(PSLv2Parser.CoefficientContext ctx) { }

	@Override public void enterSelector(PSLv2Parser.SelectorContext ctx) { }
	@Override public void exitSelector(PSLv2Parser.SelectorContext ctx) { }

	@Override public void enterAtom(PSLv2Parser.AtomContext ctx) { }
	@Override public void exitAtom(PSLv2Parser.AtomContext ctx) { }

	@Override public void enterConstraint_atom(PSLv2Parser.Constraint_atomContext ctx) { }
	@Override public void exitConstraint_atom(PSLv2Parser.Constraint_atomContext ctx) { }

	@Override public void enterExponent_expression(PSLv2Parser.Exponent_expressionContext ctx) { }
	@Override public void exitExponent_expression(PSLv2Parser.Exponent_expressionContext ctx) { }

	@Override public void enterImplied_by(PSLv2Parser.Implied_byContext ctx) { }
	@Override public void exitImplied_by(PSLv2Parser.Implied_byContext ctx) { }

	@Override public void enterBool_expression(PSLv2Parser.Bool_expressionContext ctx) { }
	@Override public void exitBool_expression(PSLv2Parser.Bool_expressionContext ctx) { }

	@Override public void enterPredicate(PSLv2Parser.PredicateContext ctx) { }
	@Override public void exitPredicate(PSLv2Parser.PredicateContext ctx) { }

	@Override public void enterGreater_than_equal(PSLv2Parser.Greater_than_equalContext ctx) { }
	@Override public void exitGreater_than_equal(PSLv2Parser.Greater_than_equalContext ctx) { }

	@Override public void enterSubtype_definition(PSLv2Parser.Subtype_definitionContext ctx) { }
	@Override public void exitSubtype_definition(PSLv2Parser.Subtype_definitionContext ctx) { }

	@Override public void enterConstraint_literal(PSLv2Parser.Constraint_literalContext ctx) { }
	@Override public void exitConstraint_literal(PSLv2Parser.Constraint_literalContext ctx) { }

	@Override public void enterArithmetic_operator(PSLv2Parser.Arithmetic_operatorContext ctx) { }
	@Override public void exitArithmetic_operator(PSLv2Parser.Arithmetic_operatorContext ctx) { }

	@Override public void enterConjunctive_clause(PSLv2Parser.Conjunctive_clauseContext ctx) { }
	@Override public void exitConjunctive_clause(PSLv2Parser.Conjunctive_clauseContext ctx) { }

	@Override public void enterRule_expression(PSLv2Parser.Rule_expressionContext ctx) { }
	@Override public void exitRule_expression(PSLv2Parser.Rule_expressionContext ctx) { }

	@Override public void enterCoeff_operator(PSLv2Parser.Coeff_operatorContext ctx) { }
	@Override public void exitCoeff_operator(PSLv2Parser.Coeff_operatorContext ctx) { }

	@Override public void enterRule_definition(PSLv2Parser.Rule_definitionContext ctx) { }
	@Override public void exitRule_definition(PSLv2Parser.Rule_definitionContext ctx) { }

	@Override public void enterPredicate_definition(PSLv2Parser.Predicate_definitionContext ctx) { }
	@Override public void exitPredicate_definition(PSLv2Parser.Predicate_definitionContext ctx) { }

	@Override public void enterConstraint_term(PSLv2Parser.Constraint_termContext ctx) { }
	@Override public void exitConstraint_term(PSLv2Parser.Constraint_termContext ctx) { }

	@Override public void enterTerm_operator(PSLv2Parser.Term_operatorContext ctx) { }
	@Override public void exitTerm_operator(PSLv2Parser.Term_operatorContext ctx) { }

	@Override public void enterTerm_not_equal(PSLv2Parser.Term_not_equalContext ctx) { }
	@Override public void exitTerm_not_equal(PSLv2Parser.Term_not_equalContext ctx) { }

	@Override public void enterOr(PSLv2Parser.OrContext ctx) { }
	@Override public void exitOr(PSLv2Parser.OrContext ctx) { }

	@Override public void enterConstraint_definition(PSLv2Parser.Constraint_definitionContext ctx) { }
	@Override public void exitConstraint_definition(PSLv2Parser.Constraint_definitionContext ctx) { }

	@Override public void enterConstraint_expression(PSLv2Parser.Constraint_expressionContext ctx) { }
	@Override public void exitConstraint_expression(PSLv2Parser.Constraint_expressionContext ctx) { }

	@Override public void enterLinear_operator(PSLv2Parser.Linear_operatorContext ctx) { }
	@Override public void exitLinear_operator(PSLv2Parser.Linear_operatorContext ctx) { }

	@Override public void enterConstraint_operator(PSLv2Parser.Constraint_operatorContext ctx) { }
	@Override public void exitConstraint_operator(PSLv2Parser.Constraint_operatorContext ctx) { }

	@Override public void enterSymmetric(PSLv2Parser.SymmetricContext ctx) { }
	@Override public void exitSymmetric(PSLv2Parser.SymmetricContext ctx) { }

	@Override public void enterNumber(PSLv2Parser.NumberContext ctx) { }
	@Override public void exitNumber(PSLv2Parser.NumberContext ctx) { }

	@Override public void enterConstraint_operand(PSLv2Parser.Constraint_operandContext ctx) { }
	@Override public void exitConstraint_operand(PSLv2Parser.Constraint_operandContext ctx) { }

	@Override public void enterLess_than_equal(PSLv2Parser.Less_than_equalContext ctx) { }
	@Override public void exitLess_than_equal(PSLv2Parser.Less_than_equalContext ctx) { }

	@Override public void enterDisjunctive_clause(PSLv2Parser.Disjunctive_clauseContext ctx) { }
	@Override public void exitDisjunctive_clause(PSLv2Parser.Disjunctive_clauseContext ctx) { }

	@Override public void enterWeight_expression(PSLv2Parser.Weight_expressionContext ctx) { }
	@Override public void exitWeight_expression(PSLv2Parser.Weight_expressionContext ctx) { }

	@Override public void enterAnd(PSLv2Parser.AndContext ctx) { }
	@Override public void exitAnd(PSLv2Parser.AndContext ctx) { }

	@Override public void enterTerm(PSLv2Parser.TermContext ctx) { }
	@Override public void exitTerm(PSLv2Parser.TermContext ctx) { }

	@Override public void enterProgram(PSLv2Parser.ProgramContext ctx) { }
	@Override public void exitProgram(PSLv2Parser.ProgramContext ctx) { }

	@Override public void enterThen(PSLv2Parser.ThenContext ctx) { }
	@Override public void exitThen(PSLv2Parser.ThenContext ctx) { }

	@Override public void enterTerm_equal(PSLv2Parser.Term_equalContext ctx) { }
	@Override public void exitTerm_equal(PSLv2Parser.Term_equalContext ctx) { }

	@Override public void enterArgumentType(PSLv2Parser.ArgumentTypeContext ctx) { }
	@Override public void exitArgumentType(PSLv2Parser.ArgumentTypeContext ctx) { }

	@Override public void enterVariable(PSLv2Parser.VariableContext ctx) { }
	@Override public void exitVariable(PSLv2Parser.VariableContext ctx) { }

	@Override public void enterLiteral(PSLv2Parser.LiteralContext ctx) { }
	@Override public void exitLiteral(PSLv2Parser.LiteralContext ctx) { }

	@Override public void enterEveryRule(ParserRuleContext ctx) { }
	@Override public void exitEveryRule(ParserRuleContext ctx) { }
	@Override public void visitTerminal(TerminalNode node) { }
	@Override public void visitErrorNode(ErrorNode node) { }
}