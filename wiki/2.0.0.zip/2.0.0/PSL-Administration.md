---
layout: wiki
---

- [Releasing a New Stable Version](Releasing-a-New-Stable-Version.md)
- [Updating the Version Number](Updating-the-Version-Number.md)
- [Updating the Copyright Notice](Updating-the-Copyright-Notice.md)