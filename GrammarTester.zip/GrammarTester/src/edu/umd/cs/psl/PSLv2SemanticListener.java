// Generated from /Users/bach/NetBeansProjects/GrammarTester/src/edu/umd/cs/psl/PSLv2.g4 by ANTLR 4.0
package edu.umd.cs.psl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PSLv2SemanticListener extends PSLv2BaseListener {
	
	protected Map<String, List<String>> predicates = new HashMap<String, List<String>>();
	
	@Override public void enterPredicate_definition(PSLv2Parser.Predicate_definitionContext ctx) {
		//System.out.println(ctx.getStart().getText());
	}
}