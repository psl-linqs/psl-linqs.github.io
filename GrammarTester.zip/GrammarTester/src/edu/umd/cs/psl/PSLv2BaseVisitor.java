// Generated from /Users/bach/NetBeansProjects/GrammarTester/src/edu/umd/cs/psl/PSLv2.g4 by ANTLR 4.0
package edu.umd.cs.psl;
import org.antlr.v4.runtime.tree.*;
import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.ParserRuleContext;

public class PSLv2BaseVisitor<T> extends AbstractParseTreeVisitor<T> implements PSLv2Visitor<T> {
	@Override public T visitCoefficient(PSLv2Parser.CoefficientContext ctx) { return visitChildren(ctx); }

	@Override public T visitSelector(PSLv2Parser.SelectorContext ctx) { return visitChildren(ctx); }

	@Override public T visitAtom(PSLv2Parser.AtomContext ctx) { return visitChildren(ctx); }

	@Override public T visitConstraint_atom(PSLv2Parser.Constraint_atomContext ctx) { return visitChildren(ctx); }

	@Override public T visitExponent_expression(PSLv2Parser.Exponent_expressionContext ctx) { return visitChildren(ctx); }

	@Override public T visitImplied_by(PSLv2Parser.Implied_byContext ctx) { return visitChildren(ctx); }

	@Override public T visitBool_expression(PSLv2Parser.Bool_expressionContext ctx) { return visitChildren(ctx); }

	@Override public T visitPredicate(PSLv2Parser.PredicateContext ctx) { return visitChildren(ctx); }

	@Override public T visitGreater_than_equal(PSLv2Parser.Greater_than_equalContext ctx) { return visitChildren(ctx); }

	@Override public T visitSubtype_definition(PSLv2Parser.Subtype_definitionContext ctx) { return visitChildren(ctx); }

	@Override public T visitConstraint_literal(PSLv2Parser.Constraint_literalContext ctx) { return visitChildren(ctx); }

	@Override public T visitArithmetic_operator(PSLv2Parser.Arithmetic_operatorContext ctx) { return visitChildren(ctx); }

	@Override public T visitConjunctive_clause(PSLv2Parser.Conjunctive_clauseContext ctx) { return visitChildren(ctx); }

	@Override public T visitRule_expression(PSLv2Parser.Rule_expressionContext ctx) { return visitChildren(ctx); }

	@Override public T visitCoeff_operator(PSLv2Parser.Coeff_operatorContext ctx) { return visitChildren(ctx); }

	@Override public T visitRule_definition(PSLv2Parser.Rule_definitionContext ctx) { return visitChildren(ctx); }

	@Override public T visitPredicate_definition(PSLv2Parser.Predicate_definitionContext ctx) { return visitChildren(ctx); }

	@Override public T visitConstraint_term(PSLv2Parser.Constraint_termContext ctx) { return visitChildren(ctx); }

	@Override public T visitTerm_operator(PSLv2Parser.Term_operatorContext ctx) { return visitChildren(ctx); }

	@Override public T visitTerm_not_equal(PSLv2Parser.Term_not_equalContext ctx) { return visitChildren(ctx); }

	@Override public T visitOr(PSLv2Parser.OrContext ctx) { return visitChildren(ctx); }

	@Override public T visitConstraint_definition(PSLv2Parser.Constraint_definitionContext ctx) { return visitChildren(ctx); }

	@Override public T visitConstraint_expression(PSLv2Parser.Constraint_expressionContext ctx) { return visitChildren(ctx); }

	@Override public T visitLinear_operator(PSLv2Parser.Linear_operatorContext ctx) { return visitChildren(ctx); }

	@Override public T visitConstraint_operator(PSLv2Parser.Constraint_operatorContext ctx) { return visitChildren(ctx); }

	@Override public T visitSymmetric(PSLv2Parser.SymmetricContext ctx) { return visitChildren(ctx); }

	@Override public T visitNumber(PSLv2Parser.NumberContext ctx) { return visitChildren(ctx); }

	@Override public T visitConstraint_operand(PSLv2Parser.Constraint_operandContext ctx) { return visitChildren(ctx); }

	@Override public T visitLess_than_equal(PSLv2Parser.Less_than_equalContext ctx) { return visitChildren(ctx); }

	@Override public T visitDisjunctive_clause(PSLv2Parser.Disjunctive_clauseContext ctx) { return visitChildren(ctx); }

	@Override public T visitWeight_expression(PSLv2Parser.Weight_expressionContext ctx) { return visitChildren(ctx); }

	@Override public T visitAnd(PSLv2Parser.AndContext ctx) { return visitChildren(ctx); }

	@Override public T visitTerm(PSLv2Parser.TermContext ctx) { return visitChildren(ctx); }

	@Override public T visitProgram(PSLv2Parser.ProgramContext ctx) { return visitChildren(ctx); }

	@Override public T visitThen(PSLv2Parser.ThenContext ctx) { return visitChildren(ctx); }

	@Override public T visitTerm_equal(PSLv2Parser.Term_equalContext ctx) { return visitChildren(ctx); }

	@Override public T visitArgumentType(PSLv2Parser.ArgumentTypeContext ctx) { return visitChildren(ctx); }

	@Override public T visitVariable(PSLv2Parser.VariableContext ctx) { return visitChildren(ctx); }

	@Override public T visitLiteral(PSLv2Parser.LiteralContext ctx) { return visitChildren(ctx); }
}