// Generated from /Users/bach/NetBeansProjects/GrammarTester/src/edu/umd/cs/psl/PSLv2.g4 by ANTLR 4.0
package edu.umd.cs.psl;
import org.antlr.v4.runtime.tree.*;
import org.antlr.v4.runtime.Token;

public interface PSLv2Visitor<T> extends ParseTreeVisitor<T> {
	T visitCoefficient(PSLv2Parser.CoefficientContext ctx);

	T visitSelector(PSLv2Parser.SelectorContext ctx);

	T visitAtom(PSLv2Parser.AtomContext ctx);

	T visitConstraint_atom(PSLv2Parser.Constraint_atomContext ctx);

	T visitExponent_expression(PSLv2Parser.Exponent_expressionContext ctx);

	T visitImplied_by(PSLv2Parser.Implied_byContext ctx);

	T visitBool_expression(PSLv2Parser.Bool_expressionContext ctx);

	T visitPredicate(PSLv2Parser.PredicateContext ctx);

	T visitGreater_than_equal(PSLv2Parser.Greater_than_equalContext ctx);

	T visitSubtype_definition(PSLv2Parser.Subtype_definitionContext ctx);

	T visitConstraint_literal(PSLv2Parser.Constraint_literalContext ctx);

	T visitArithmetic_operator(PSLv2Parser.Arithmetic_operatorContext ctx);

	T visitConjunctive_clause(PSLv2Parser.Conjunctive_clauseContext ctx);

	T visitRule_expression(PSLv2Parser.Rule_expressionContext ctx);

	T visitCoeff_operator(PSLv2Parser.Coeff_operatorContext ctx);

	T visitRule_definition(PSLv2Parser.Rule_definitionContext ctx);

	T visitPredicate_definition(PSLv2Parser.Predicate_definitionContext ctx);

	T visitConstraint_term(PSLv2Parser.Constraint_termContext ctx);

	T visitTerm_operator(PSLv2Parser.Term_operatorContext ctx);

	T visitTerm_not_equal(PSLv2Parser.Term_not_equalContext ctx);

	T visitOr(PSLv2Parser.OrContext ctx);

	T visitConstraint_definition(PSLv2Parser.Constraint_definitionContext ctx);

	T visitConstraint_expression(PSLv2Parser.Constraint_expressionContext ctx);

	T visitLinear_operator(PSLv2Parser.Linear_operatorContext ctx);

	T visitConstraint_operator(PSLv2Parser.Constraint_operatorContext ctx);

	T visitSymmetric(PSLv2Parser.SymmetricContext ctx);

	T visitNumber(PSLv2Parser.NumberContext ctx);

	T visitConstraint_operand(PSLv2Parser.Constraint_operandContext ctx);

	T visitLess_than_equal(PSLv2Parser.Less_than_equalContext ctx);

	T visitDisjunctive_clause(PSLv2Parser.Disjunctive_clauseContext ctx);

	T visitWeight_expression(PSLv2Parser.Weight_expressionContext ctx);

	T visitAnd(PSLv2Parser.AndContext ctx);

	T visitTerm(PSLv2Parser.TermContext ctx);

	T visitProgram(PSLv2Parser.ProgramContext ctx);

	T visitThen(PSLv2Parser.ThenContext ctx);

	T visitTerm_equal(PSLv2Parser.Term_equalContext ctx);

	T visitArgumentType(PSLv2Parser.ArgumentTypeContext ctx);

	T visitVariable(PSLv2Parser.VariableContext ctx);

	T visitLiteral(PSLv2Parser.LiteralContext ctx);
}