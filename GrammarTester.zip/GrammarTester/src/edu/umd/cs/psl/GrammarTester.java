package edu.umd.cs.psl;

import org.antlr.v4.runtime.ANTLRFileStream;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.Token;

/**
 *
 * @author bach
 */
public class GrammarTester {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) throws Exception {
		PSLv2Lexer lexer = new PSLv2Lexer(new ANTLRFileStream("input.txt"));
		for (Token token : lexer.getAllTokens()) {
			System.out.print(lexer.getTokenNames()[token.getType()] + " ");
		}
		System.out.println();
		lexer.reset();
		CommonTokenStream tokens = new CommonTokenStream(lexer);
		PSLv2Parser parser = new PSLv2Parser(tokens);
		parser.addParseListener(new PSLv2SemanticListener());
		parser.program();
	}
}
