// Generated from /Users/bach/NetBeansProjects/GrammarTester/src/edu/umd/cs/psl/PSLv2.g4 by ANTLR 4.0
package edu.umd.cs.psl;
import org.antlr.v4.runtime.tree.*;
import org.antlr.v4.runtime.Token;

public interface PSLv2Listener extends ParseTreeListener {
	void enterCoefficient(PSLv2Parser.CoefficientContext ctx);
	void exitCoefficient(PSLv2Parser.CoefficientContext ctx);

	void enterSelector(PSLv2Parser.SelectorContext ctx);
	void exitSelector(PSLv2Parser.SelectorContext ctx);

	void enterAtom(PSLv2Parser.AtomContext ctx);
	void exitAtom(PSLv2Parser.AtomContext ctx);

	void enterConstraint_atom(PSLv2Parser.Constraint_atomContext ctx);
	void exitConstraint_atom(PSLv2Parser.Constraint_atomContext ctx);

	void enterExponent_expression(PSLv2Parser.Exponent_expressionContext ctx);
	void exitExponent_expression(PSLv2Parser.Exponent_expressionContext ctx);

	void enterImplied_by(PSLv2Parser.Implied_byContext ctx);
	void exitImplied_by(PSLv2Parser.Implied_byContext ctx);

	void enterBool_expression(PSLv2Parser.Bool_expressionContext ctx);
	void exitBool_expression(PSLv2Parser.Bool_expressionContext ctx);

	void enterPredicate(PSLv2Parser.PredicateContext ctx);
	void exitPredicate(PSLv2Parser.PredicateContext ctx);

	void enterGreater_than_equal(PSLv2Parser.Greater_than_equalContext ctx);
	void exitGreater_than_equal(PSLv2Parser.Greater_than_equalContext ctx);

	void enterSubtype_definition(PSLv2Parser.Subtype_definitionContext ctx);
	void exitSubtype_definition(PSLv2Parser.Subtype_definitionContext ctx);

	void enterConstraint_literal(PSLv2Parser.Constraint_literalContext ctx);
	void exitConstraint_literal(PSLv2Parser.Constraint_literalContext ctx);

	void enterArithmetic_operator(PSLv2Parser.Arithmetic_operatorContext ctx);
	void exitArithmetic_operator(PSLv2Parser.Arithmetic_operatorContext ctx);

	void enterConjunctive_clause(PSLv2Parser.Conjunctive_clauseContext ctx);
	void exitConjunctive_clause(PSLv2Parser.Conjunctive_clauseContext ctx);

	void enterRule_expression(PSLv2Parser.Rule_expressionContext ctx);
	void exitRule_expression(PSLv2Parser.Rule_expressionContext ctx);

	void enterCoeff_operator(PSLv2Parser.Coeff_operatorContext ctx);
	void exitCoeff_operator(PSLv2Parser.Coeff_operatorContext ctx);

	void enterRule_definition(PSLv2Parser.Rule_definitionContext ctx);
	void exitRule_definition(PSLv2Parser.Rule_definitionContext ctx);

	void enterPredicate_definition(PSLv2Parser.Predicate_definitionContext ctx);
	void exitPredicate_definition(PSLv2Parser.Predicate_definitionContext ctx);

	void enterConstraint_term(PSLv2Parser.Constraint_termContext ctx);
	void exitConstraint_term(PSLv2Parser.Constraint_termContext ctx);

	void enterTerm_operator(PSLv2Parser.Term_operatorContext ctx);
	void exitTerm_operator(PSLv2Parser.Term_operatorContext ctx);

	void enterTerm_not_equal(PSLv2Parser.Term_not_equalContext ctx);
	void exitTerm_not_equal(PSLv2Parser.Term_not_equalContext ctx);

	void enterOr(PSLv2Parser.OrContext ctx);
	void exitOr(PSLv2Parser.OrContext ctx);

	void enterConstraint_definition(PSLv2Parser.Constraint_definitionContext ctx);
	void exitConstraint_definition(PSLv2Parser.Constraint_definitionContext ctx);

	void enterConstraint_expression(PSLv2Parser.Constraint_expressionContext ctx);
	void exitConstraint_expression(PSLv2Parser.Constraint_expressionContext ctx);

	void enterLinear_operator(PSLv2Parser.Linear_operatorContext ctx);
	void exitLinear_operator(PSLv2Parser.Linear_operatorContext ctx);

	void enterConstraint_operator(PSLv2Parser.Constraint_operatorContext ctx);
	void exitConstraint_operator(PSLv2Parser.Constraint_operatorContext ctx);

	void enterSymmetric(PSLv2Parser.SymmetricContext ctx);
	void exitSymmetric(PSLv2Parser.SymmetricContext ctx);

	void enterNumber(PSLv2Parser.NumberContext ctx);
	void exitNumber(PSLv2Parser.NumberContext ctx);

	void enterConstraint_operand(PSLv2Parser.Constraint_operandContext ctx);
	void exitConstraint_operand(PSLv2Parser.Constraint_operandContext ctx);

	void enterLess_than_equal(PSLv2Parser.Less_than_equalContext ctx);
	void exitLess_than_equal(PSLv2Parser.Less_than_equalContext ctx);

	void enterDisjunctive_clause(PSLv2Parser.Disjunctive_clauseContext ctx);
	void exitDisjunctive_clause(PSLv2Parser.Disjunctive_clauseContext ctx);

	void enterWeight_expression(PSLv2Parser.Weight_expressionContext ctx);
	void exitWeight_expression(PSLv2Parser.Weight_expressionContext ctx);

	void enterAnd(PSLv2Parser.AndContext ctx);
	void exitAnd(PSLv2Parser.AndContext ctx);

	void enterTerm(PSLv2Parser.TermContext ctx);
	void exitTerm(PSLv2Parser.TermContext ctx);

	void enterProgram(PSLv2Parser.ProgramContext ctx);
	void exitProgram(PSLv2Parser.ProgramContext ctx);

	void enterThen(PSLv2Parser.ThenContext ctx);
	void exitThen(PSLv2Parser.ThenContext ctx);

	void enterTerm_equal(PSLv2Parser.Term_equalContext ctx);
	void exitTerm_equal(PSLv2Parser.Term_equalContext ctx);

	void enterArgumentType(PSLv2Parser.ArgumentTypeContext ctx);
	void exitArgumentType(PSLv2Parser.ArgumentTypeContext ctx);

	void enterVariable(PSLv2Parser.VariableContext ctx);
	void exitVariable(PSLv2Parser.VariableContext ctx);

	void enterLiteral(PSLv2Parser.LiteralContext ctx);
	void exitLiteral(PSLv2Parser.LiteralContext ctx);
}