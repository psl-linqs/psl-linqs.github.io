---
layout: wiki
---

Example PSL programs are available at [https://bitbucket.org/linqs/psl-examples](https://bitbucket.org/linqs/psl-examples).

Each example contains a script called `run.sh` which will handle all the building and running.

A detailed walkthrough of an example can he found [here](Example-Walkthrough.md).